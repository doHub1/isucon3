Python3 port for pure python memcached client library, ported and being
kept up to date by https://github.com/eguven

Please report issues and submit code changes to the github repository at:

    https://github.com/eguven/python3-memcached

Below is the original README content.

This package was originally written by Evan Martin of Danga.
Sean Reifschneider of tummy.com, ltd. has taken over maintenance of it.

This software is a 100% Python interface to the memcached memory cache
daemon.  It is the client side software which allows storing values in one
or more, possibly remote, memcached servers.  Search google for memcached
for more information.


